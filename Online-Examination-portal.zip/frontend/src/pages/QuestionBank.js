const QuestionBank = () => {
    return <h2>Question Bank</h2>;
  };
  
  export default QuestionBank;
  