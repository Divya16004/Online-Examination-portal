const AssignTests = () => {
    return <h2>Assign or Schedule Tests</h2>;
  };
  
  export default AssignTests;
  