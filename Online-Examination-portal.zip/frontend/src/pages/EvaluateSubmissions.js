const EvaluateSubmissions = () => {
    return <h2>Evaluate or Grade Submissions</h2>;
  };
  
  export default EvaluateSubmissions;
  